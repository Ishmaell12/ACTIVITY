package com.jms.activityprogram;

import androidx.appcompat.app.AppCompatActivity;
import android.View.view;

import android.os.Bundle;

public class ActivitySecond extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }
}